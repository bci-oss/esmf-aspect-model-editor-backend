customElements.define('ame-plugin-bruno-test', class extends HTMLElement {});
